
class X
    {
    int a;
    };
