#ifndef __ALPHA_SETUP_H
#define __ALPHA_SETUP_H

#define COMMAND_LINE_SIZE	256

#endif
