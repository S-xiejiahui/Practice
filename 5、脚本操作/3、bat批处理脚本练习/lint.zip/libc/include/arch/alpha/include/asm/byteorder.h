#ifndef _ALPHA_BYTEORDER_H
#define _ALPHA_BYTEORDER_H

#include <linux/byteorder/little_endian.h>

#endif /* _ALPHA_BYTEORDER_H */
