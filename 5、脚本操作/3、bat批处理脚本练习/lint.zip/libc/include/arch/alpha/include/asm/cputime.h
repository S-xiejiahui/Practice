#ifndef __ALPHA_CPUTIME_H
#define __ALPHA_CPUTIME_H

#include <asm-generic/cputime.h>

#endif /* __ALPHA_CPUTIME_H */
