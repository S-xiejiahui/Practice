/*
 *  linux/arch/arm/kernel/compat.h
 *
 *  Copyright (C) 2001 Russell King
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
*/

extern void convert_to_tag_list(struct tag *tags);
