#ifndef __MACH_STAMP9G20_H
#define __MACH_STAMP9G20_H

void stamp9g20_init_early(void);
void stamp9g20_board_init(void);

#endif
