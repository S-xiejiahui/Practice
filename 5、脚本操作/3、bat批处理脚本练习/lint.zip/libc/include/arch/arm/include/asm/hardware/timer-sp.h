void sp804_clocksource_init(void __iomem *, const char *);
void sp804_clockevents_init(void __iomem *, unsigned int, const char *);
