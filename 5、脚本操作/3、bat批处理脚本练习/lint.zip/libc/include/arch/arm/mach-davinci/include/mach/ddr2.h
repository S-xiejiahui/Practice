#define DDR2_SDRCR_OFFSET	0xc
#define DDR2_SRPD_BIT		(1 << 23)
#define DDR2_MCLKSTOPEN_BIT	(1 << 30)
#define DDR2_LPMODEN_BIT	(1 << 31)
