
//lint -w2  reduce the warning level to 2

class X
    {
    static int a;
    };
